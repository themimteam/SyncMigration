PARAM ([string]$ReportFolder="E:\Scripts\Migration\Sync\data",[string]$prefix1,[string]$prefix2)

###
###  CompareCSV-SyncConfig
###
###  Written by Carol Wapshere
###
###  Uses fc to compare the configuation of two different Sync Service installations.
###   - Designed to run after ConvertToCSV-SyncConfig.ps1 to compare the CSV reports for two servers,
###   - The CSV reports for both servers are assumed to be in the same folder, with different prefixes,
###   - The CSV file names are expected to be the same as in ConvertToCSV-SyncConfig.ps1.
###
###  Parameters:
###     -ReportFolder          The folder where the CSV files have been saved
###     -prefix1               The CSV file prefix for the first server
###     -prefix2               The CSV file prefix for the second server
###


Function CompareCSV
{
    PARAM($file1,$file2)
    END
    {
        # Read file contents
        $path1 = $ReportFolder + "\" + $file1
        $path2 = $ReportFolder + "\" + $file2  
        if (-not (Test-Path $path2)) {Throw "No prefix2 file corresponding to $file1"}
              
        $csv1 = import-csv $path1 -Delimiter ";"
        $csv2 = import-csv $path2 -Delimiter ";"
        
        # Get columns
        $cols = (get-content $path1)[0].split(";")
        $outCols = @("SideIndicator")
        foreach ($col in $cols) {$outCols += $col}
        
        # Find differences between the two CSVs
        $diffs = compare-object -ReferenceObject $csv1 -DifferenceObject $csv2 -Property $cols
        
        # Export differences 
        $diffFile = $ReportFolder + "\diff_" + $file1.split("_")[1]
        "Writing $diffFile"
        if ($diffs)
        {       
            $diffs
            $diffs | foreach {if ($_.SideIndicator -eq "<=") {$_.SideIndicator = $file1} else {$_.SideIndicator = $file2} }
            $diffs | select-object $outCols `
                   | convertto-csv -delimiter ";" -notypeinformation `
                   | out-file -FilePath $diffFile -encoding "Default"
        }
        else
        {
            "No differences" | out-file -FilePath $diffFile -encoding "Default"
        }
    }
}

$files1 = Get-ChildItem -Path $ReportFolder -Filter ($prefix1 + "*.csv")
foreach ($file in $files1)
{
    $file1 = $file.Name
    $file2 = $file1.Replace($prefix1 + "_", $prefix2 + "_")
    CompareCSV $file1 $file2
}

