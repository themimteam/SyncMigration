PARAM ( [string]$ServerConfigFolder,[string]$ReportFolder="E:\Scripts\Migration\Sync\data",[string]$prefix)
#Copyright (c) 2013, Unify Solutions Pty Ltd
#All rights reserved.
#
#Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
#* Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
#* Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
#
#THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
#IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
#OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

###
###  ConvertToCSV-SyncConfig
###
###  Written by Carol Wapshere
###
###  Converts Sync Config to CSVs which may be used for documentation, or which may be compared to
###  another system to check if there are differences in configuration.
###
###  Parameters:
###     -ServerConfigFolder    The folder containing a full server export
###     -ReportFolder          The folder where the CSV files are to be saved
###     -prefix                (Optional) A prefix for the CSV filenames - must use when comparing two server exports
###
###  Example usage:  ConvertToCSV-SyncConfig -ServerConfigFolder "E:\SvrConfig" -ReportFolder "E:\temp" -prefix "dev"


## Collect Hash Tables with details about each MA and the rules configured in it

$hashMANameToGuid = @{}
$hashMAGuidToName = @{}
$hashConnFilter = @{}
$hashJoin = @{}
$hashPrj = @{}
$hashEAF = @{}
$hashRP = @{}

foreach ($MAFile in (Get-ChildItem $ServerConfigFolder | where {$_.Name -match "MA"}))
{
    [xml]$MA = get-content "$ServerConfigFolder\$MAFile"
    $MAid = $MA."saved-ma-configuration"."ma-data".id
    $MAName = $MA."saved-ma-configuration"."ma-data".name

    $hashMANameToGuid.Add($MAName,$MAid)
    $hashMAGuidToName.Add($MAid,$MAName)


    #Connector Filters
    if (-not $hashConnFilter.ContainsKey($MAid)) {$hashConnFilter.Add($MAid,@{})}

    if ($MA."saved-ma-configuration"."ma-data"."stay-disconnector")
    {
        foreach($FilterSet in $MA."saved-ma-configuration"."ma-data"."stay-disconnector"."filter-set")
        {
            $CSObjectType = $FilterSet."cd-object-type"
            if (-not $hashConnFilter.($MAid).ContainsKey($CSObjectType)) {$hashConnFilter.($MAid).Add($CSObjectType,@())}

            foreach ($CF in $FilterSet."filter-alternative")
            {
                $text = $CF.condition."cd-attribute" + " " + $CF.condition.operator + " " + $CF.condition.value
                $hashConnFilter.($MAid).($CSObjectType) += $text
            }
        }
    }


    # Join Rules
    if (-not $hashJoin.ContainsKey($MAid)) {$hashJoin.Add($MAid,@{})}

    foreach ($CSObjectRule in $MA."saved-ma-configuration"."ma-data".join."join-profile")
    {
        if ($CSObjectRule)
        {
            $CSObjectType = $CSObjectRule."cd-object-type"
            if (-not $hashJoin.($MAid).ContainsKey($CSObjectType)) {$hashJoin.($MAid).Add($CSObjectType,@{})}

            foreach ($JoinRule in $CSObjectRule."join-criterion")
            {
                $RuleID = $JoinRule.id
                $hashJoin.($MAid).($CSObjectType).Add($RuleID,@{})

                $hashJoin.($MAid).($CSObjectType).($RuleID).Add("MVAttrib",$JoinRule.search."attribute-mapping"."mv-attribute")

                if ($JoinRule.search."attribute-mapping"."direct-mapping"."src-attribute")
                {
                    $hashJoin.($MAid).($CSObjectType).($RuleID).Add("Type","Direct")
                    $CSAttrib = @()
                    foreach ($attr in $JoinRule.search."attribute-mapping"."direct-mapping"."src-attribute")
                    {
                        if ($attr."#text") {$CSAttrib += $attr."#text"}
                        else {$CSAttrib += $attr}
                    }
                    $hashJoin.($MAid).($CSObjectType).($RuleID).Add("CSAttrib",$CSAttrib)
                }
                elseif ($JoinRule.search."attribute-mapping"."scripted-mapping"."src-attribute")
                {
                    $hashJoin.($MAid).($CSObjectType).($RuleID).Add("Type","Advanced")
                    $CSAttrib = @()
                    foreach ($attr in $JoinRule.search."attribute-mapping"."scripted-mapping"."src-attribute")
                    {
                        if ($attr."#text") {$CSAttrib += $attr."#text"}
                        else {$CSAttrib += $attr}
                    }
                    $hashJoin.($MAid).($CSObjectType).($RuleID).Add("CSAttributes",$CSAttrib)
                }
            }
        }
    }

    #Projection Rules
    if (-not $hashPrj.ContainsKey($MAid)) {$hashPrj.Add($MAid,@{})}

    foreach ($CSObjectRule in $MA."saved-ma-configuration"."ma-data".projection."class-mapping")
    {
        if ($CSObjectRule) {foreach ($PrjRule in $CSObjectRule)
        {
            $CSObjectType = $PrjRule."cd-object-type"
            $hashPrj.($MAid).Add($CSObjectType,@{})
            $hashPrj.($MAid).($CSObjectType).Add("MVObjectType",$PrjRule."mv-object-type")
            $hashPrj.($MAid).($CSObjectType).Add("Type",$PrjRule.type)
        }}
    }

    #Export Flows
    if (-not $hashEAF.ContainsKey($MAid)) {$hashEAF.Add($MAid,@{})}

    foreach ($CSObjectRule in $MA."saved-ma-configuration"."ma-data"."export-attribute-flow"."export-flow-set")
    {
        if ($CSObjectRule)
        {
            $CSObjectType = $CSObjectRule."cd-object-type"
            if (-not $hashEAF.($MAid).ContainsKey($CSObjectType)) {$hashEAF.($MAid).Add($CSObjectType,@{})}

            # MV Object Type
            $hashEAF.($MAid).($CSObjectType).Add("MVObjectType",$CSObjectRule."mv-object-type")

            # Flow Rules
            $hashEAF.($MAid).($CSObjectType).Add("FlowRules",@{})
            foreach ($EAF in $CSObjectRule."export-flow")
            {
                $CSAttrib = $EAF."cd-attribute"
                $hashEAF.($MAid).($CSObjectType).("FlowRules").Add($CSAttrib,@{})

                if ($EAF."direct-mapping")
                {
                    $hashEAF.($MAid).($CSObjectType).("FlowRules").($CSAttrib).Add("Type","Direct")
                    $MVAttrib = @()
                    foreach ($attr in $EAF."direct-mapping"."src-attribute")
                    {
                        if ($attr."#text") {$MVAttrib += $attr."#text"}
                        else {$MVAttrib += $attr}
                    }
                    $hashEAF.($MAid).($CSObjectType).("FlowRules").($CSAttrib).Add("MVAttrib",$MVAttrib)
                }
                elseif ($EAF."scripted-mapping")
                {
                    $hashEAF.($MAid).($CSObjectType).("FlowRules").($CSAttrib).Add("Type",@("Advanced",$EAF."scripted-mapping"."script-context"))
                    $MVAttrib = @()
                    foreach ($attr in $EAF."scripted-mapping"."src-attribute")
                    {
                        if ($attr."#text") {$MVAttrib += $attr."#text"}
                        else {$MVAttrib += $attr}
                    }
                    $hashEAF.($MAid).($CSObjectType).("FlowRules").($CSAttrib).Add("MVAttrib",$MVAttrib)
                }
                elseif ($EAF."constant-mapping")
                {
                    $hashEAF.($MAid).($CSObjectType).("FlowRules").($CSAttrib).Add("Type","Constant")
                    $hashEAF.($MAid).($CSObjectType).("FlowRules").($CSAttrib).Add("MVAttrib",$EAF."constant-mapping"."constant-value")
                }
            }
        }
    }

    # Run Profiles
    $hashRP.Add($MAid,@{})
    foreach ($RP in $MA."saved-ma-configuration"."ma-data"."ma-run-data"."run-configuration")
    {
        $steps = ""
        foreach ($step in $RP.configuration.step)
        {
            if ($steps -eq "") {$steps = $step."step-type".type}
            else {$steps = $steps + "," + $step."step-type".type}
        }
        $hashRP.($MAid).Add($RP.name,$steps)
    }

}


## Collect Hash Tables of details about Import Flow Rules
[xml]$MV = get-content "$ServerConfigFolder\MV.xml"
$ImportFlowSet = $MV."saved-mv-configuration"."mv-data"."import-attribute-flow"."import-flow-set"

$hashIAFbyObject = @{}
$hashIAFbyMA = @{}

foreach ($MVObjectFlow in $ImportFlowSet)
{
    $MVObjectType = $MVObjectFlow."mv-object-type"

    foreach ($AttrFlow in $MVObjectFlow."import-flows")
    {
        $MVAttrib = $AttrFlow."mv-attribute"
        $i = 0

        foreach ($IAF in $AttrFlow."import-flow")
        {
            $i += 1
            $RuleID = $IAF.id

            if ($AttrFlow.type -eq "ranked")
            {
                $precedence = $i.ToString()
            }
            else
            {
                $precedence = $i.ToString() + " equal"
            }


            $MAid = $IAF."src-ma"
            $MAName = $hashMAGuidToName.($MAid)
            $CSObjectType = $IAF."cd-object-type"


            # Flow rule type and CS Attributes
            if ($IAF."direct-mapping")
            {
                $Type = "Direct"
                $CSAttrib = ""
                if ($IAF."direct-mapping"."src-attribute"."#text") {$CSAttrib = $IAF."direct-mapping"."src-attribute"."#text"}
                else {$CSAttrib = $IAF."direct-mapping"."src-attribute"}
            }
            elseif ($IAF."scripted-mapping")
            {
                $Type = ("Advanced",$IAF."scripted-mapping"."script-context")
                $CSAttrib = @()
                foreach ($attr in $IAF."scripted-mapping"."src-attribute")
                {
                    if ($attr."#text") {$CSAttrib += $attr."#text"}
                    else {$CSAttrib += $attr}
                }
            }
            elseif ($IAF."constant-mapping")
            {
                $Type = "Constant"
                $CSAttrib = $IAF."constant-mapping"."constant-value"
            }

            ## Hash table by Metaverse ObjectType for the precedence tables
            if (-not $hashIAFbyObject.ContainsKey($MVObjectType)) {$hashIAFbyObject.Add($MVObjectType,@{})}
            if (-not $hashIAFbyObject.($MVObjectType).ContainsKey($MVAttrib)) {$hashIAFbyObject.($MVObjectType).Add($MVAttrib,@{})}
            $hashIAFbyObject.($MVObjectType).($MVAttrib).Add($precedence,@{})
            $hashIAFbyObject.($MVObjectType).($MVAttrib).($precedence).Add("MAName",$MAName)
            $hashIAFbyObject.($MVObjectType).($MVAttrib).($precedence).Add("CSObjectType",$CSObjectType)
            $hashIAFbyObject.($MVObjectType).($MVAttrib).($precedence).Add("Type",$Type)
            $hashIAFbyObject.($MVObjectType).($MVAttrib).($precedence).Add("CSAttrib",$CSAttrib)
    
            ## Hash table by MA for the MA sections
            if (-not $hashIAFbyMA.ContainsKey($MAid)) {$hashIAFbyMA.Add($MAid,@{})}
            if (-not $hashIAFbyMA.($MAid).ContainsKey($CSObjectType)) {$hashIAFbyMA.($MAid).Add($CSObjectType,@{})}
            $hashIAFbyMA.($MAid).($CSObjectType).Add($MVAttrib,@{})
            $hashIAFbyMA.($MAid).($CSObjectType).($MVAttrib).Add("MVObjectType",$MVObjectType)
            $hashIAFbyMA.($MAid).($CSObjectType).($MVAttrib).Add("CSAttrib",$CSAttrib)
            $hashIAFbyMA.($MAid).($CSObjectType).($MVAttrib).Add("Type",$Type)
        }
    }
}


# Enumerate metaverse schea
$hashSchema = @{}

foreach ($class in $MV."saved-mv-configuration"."mv-data".schema.dsml."directory-schema".class)
{
    $MVObjectType = $class.id
    $hashSchema.Add($MVObjectType,@())
    foreach ($attrib in $class.attribute)
    {
        $hashSchema.($MVObjectType) += $attrib.ref.Replace("#","")
    }
}

# Enumerate Metaverse object deletion rules
$hashDeletion = @{}

foreach ($rule in $MV."saved-mv-configuration"."mv-data"."mv-deletion"."mv-deletion-rule")
{
    if ($rule)
    {
        $MVObjectType = $rule."mv-object-type"
        $hashDeletion.Add($MVObjectType,@{})
        $hashDeletion.($MVObjectType).Add("Type",$rule.type)
        
        $IgnoreMAs = @()
        if ($rule."exclude-ma"){ foreach ($MAid in $rule."exclude-ma")
        {
            $IgnoreMAs += $hashMAGuidToName.($MAid)
        }}
        $hashDeletion.($MVObjectType).Add("IgnoreMAs",($IgnoreMAs | sort) -join ",")
        
        $TriggerMAs = @()
        if ($rule."src-ma"){ foreach ($MAid in $rule."src-ma")
        {
            $TriggerMAs += $hashMAGuidToName.($MAid)
        }}
        $hashDeletion.($MVObjectType).Add("TriggerMAs",($TriggerMAs | sort) -join ",")    
    }
}



###
### Generate CSV Files
###

### Metaverse Schema
$schfile = $ReportFolder + "\" + $prefix + "_Schema.csv"
"MV Object Type;MV Attribute" | Out-File $schfile -encoding "Default"

foreach ($MVObjectType in $hashSchema.Keys | sort)
{
    foreach ($MVAttrib in $hashSchema.($MVObjectType) | sort)
    {
        $MVObjectType + ";" + $MVAttrib | add-content $schfile
    }
}

### Metaverse Object Deletion
$delfile = $ReportFolder + "\" + $prefix + "_Deletion.csv"
"MV Object Type;Type;Trigger MAs;Ignore MAs" | Out-File $delfile -encoding "Default"

foreach ($MVObjectType in $hashDeletion.Keys | sort)
{
    $ColumnText = @()
    $ColumnText += $MVObjectType
    $ColumnText += $hashDeletion.($MVObjectType).Type
    $ColumnText += $hashDeletion.($MVObjectType).TriggerMAs
    $ColumnText += $hashDeletion.($MVObjectType).IgnoreMAs
    
    $ColumnText -join ";" | add-content $delfile
}


### Import flow precedence
$arraySort = @()
$precfile = $ReportFolder + "\" + $prefix + "_Precedence.csv"
"MV Object Type;MV Attribute;Management Agent;CS Object Type;Rule Type;CS Attributes;Precedence" | Out-File $precfile -encoding "Default"

foreach ($MVObjectType in ($hashIAFbyObject.Keys |sort))
{
    foreach ($MVAttr in $hashIAFbyObject.($MVObjectType).Keys | sort)
    {
        foreach ($item in $hashIAFbyObject.($MVObjectType).($MVAttr).Keys | sort)
        {
            if ($item -match "equal") {$precedence = "equal"}
            else {$precedence = $item}

            $ColumnText = @()
            $ColumnText += $MVObjectType
            $ColumnText += $MVAttr
            $ColumnText += $hashIAFbyObject.($MVObjectType).($MVAttr).($item).("MAName")
            $ColumnText += $hashIAFbyObject.($MVObjectType).($MVAttr).($item).("CSObjectType")

            $Type = $hashIAFbyObject.($MVObjectType).($MVAttr).($item).("Type")
            if ($Type.GetType().BaseType.Name -eq "Array"){$ColumnText += $Type -join "`n" }
            else {$ColumnText += $Type}

            $CSAttrib = $hashIAFbyObject.($MVObjectType).($MVAttr).($item).("CSAttrib")
            if ($CSAttrib.GetType().BaseType.Name -eq "Array"){$ColumnText += $CSAttrib -join "`n" }
            else {$ColumnText += $CSAttrib}

            $ColumnText += $precedence

            $arraySort += $ColumnText -join ";"
        }
    } 
}
foreach ($row in $arraySort | sort) {$row | add-content $precfile}


### MA Rules

$cffile = $ReportFolder + "\" + $prefix + "_ConnectorFilters.csv"
"MA;CS Object Type;Filter Rule" | Out-File $cffile -encoding "Default"
$jfile = $ReportFolder + "\" + $prefix + "_JoinRules.csv"
"MA;CS Object Type;CS Attributes;Join Type;MV Attribute" | Out-File $jfile -encoding "Default"
$prjfile = $ReportFolder + "\" + $prefix + "_ProjectionRules.csv"
"MA;CS Object Type;MV Object Type" | Out-File $prjfile -encoding "Default"
$iaffile = $ReportFolder + "\" + $prefix + "_IAFRules.csv"
"MA;CS Object Type;MV Object Type;CS Attribute;MV Attribute;Mapping Type" | Out-File $iaffile -encoding "Default"
$eaffile = $ReportFolder + "\" + $prefix + "_EAFRules.csv"
"MA;CS Object Type;MV Object Type;CS Attribute;MV Attribute;Mapping Type" | Out-File $eaffile -encoding "Default"
$rpfile = $ReportFolder + "\" + $prefix + "_RunProfiles.csv"
"MA;Run Profile;Steps" | Out-File $rpfile -encoding "Default"


foreach ($MAName in $hashMANameToGuid.Keys | sort)
{
    $MAid = $hashMANameToGuid.($MAName)
 

    ### Connector Filters
    if ($hashConnFilter.ContainsKey($MAid) -and $hashConnFilter.($MAid).count -gt 0)
    {
        foreach ($CSObjectType in $hashConnFilter.($MAid).Keys | sort)
        {
            $ColumnText = @()
            $ColumnText += $MAName
            $ColumnText += $CSObjectType
            $ColumnText += $hashConnFilter.($MAid).($CSObjectType) -join "`n"
            $ColumnText -join ";" | add-content $cffile
        }
    }


    ### Join Rules
    ### As the join rules are stored n the hashtable by Guid we need to put the CSV lines into an array for final sorting.
    $arraySort = @()
    if ($hashJoin.ContainsKey($MAid) -and $hashJoin.($MAid).count -gt 0)
    {
        foreach ($CSObjectType in $hashJoin.($MAid).Keys | sort)
        {
            foreach ($RuleID in $hashJoin.($MAid).($CSObjectType).Keys)
            {
                $ColumnText = @()
                $ColumnText += $MAName
                $ColumnText += $CSObjectType
                $ColumnText += $hashJoin.($MAid).($CSObjectType).($RuleID).("CSAttrib") -join "`n"
                $ColumnText += $hashJoin.($MAid).($CSObjectType).($RuleID).("Type")
                $ColumnText += $hashJoin.($MAid).($CSObjectType).($RuleID).("MVAttrib")
                
                $arraySort += $ColumnText -join ";" 
            }
        }
    }
    foreach ($row in $arraySort | sort) {$row | add-content $jfile}


    ### Projection Rules
    if ($hashPrj.ContainsKey($MAid) -and $hashPrj.($MAid).count -gt 0)
    {
        foreach ($CSObjectType in $hashPrj.($MAid).Keys | sort)
        {
            $ColumnText = @()
            $ColumnText += $MAName
            $ColumnText += $CSObjectType
            $ColumnText += $hashPrj.($MAid).($CSObjectType).("MVObjectType")
            $ColumnText -join ";" | add-content $prjfile
        }
    }



    ### Import Attribute Flows
    if ($hashIAFbyMA.ContainsKey($MAid) -and $hashIAFbyMA.($MAid).count -gt 0)
    {
        foreach ($CSObjectType in $hashIAFbyMA.($MAid).Keys | sort)
        {
            foreach ($MVAttrib in $hashIAFbyMA.($MAid).($CSObjectType).Keys | sort)
            {
                $ColumnText = @()
                $ColumnText += $MAName
                $ColumnText += $CSObjectType
                $ColumnText += $hashIAFbyMA.($MAid).($CSObjectType).($MVAttrib).("MVObjectType")
                $ColumnText += $hashIAFbyMA.($MAid).($CSObjectType).($MVAttrib).("CSAttrib") -join "`n"
                $ColumnText += $MVAttrib
                $ColumnText += $hashIAFbyMA.($MAid).($CSObjectType).($MVAttrib).("Type") -join "`n"
                
                $ColumnText -join ";" | add-content $iaffile
            }
        }
    }


    ### Export Attribute Flows
    if ($hashEAF.ContainsKey($MAid) -and $hashEAF.($MAid).count -gt 0)
    {
        foreach ($CSObjectType in $hashEAF.($MAid).Keys | sort)
        {                
            $MVObjectType = $hashEAF.($MAid).($CSObjectType).("MVObjectType")
            foreach ($CSAttrib in $hashEAF.($MAid).($CSObjectType).("FlowRules").Keys | sort)
            {

                $ColumnText = @()
                $ColumnText += $MAName
                $ColumnText += $CSObjectType
                $ColumnText += $MVObjectType
                $ColumnText += $CSAttrib
                $ColumnText += $hashEAF.($MAid).($CSObjectType).("FlowRules").($CSAttrib).("MVAttrib") -join "`n"
                $ColumnText += $hashEAF.($MAid).($CSObjectType).("FlowRules").($CSAttrib).("Type") -join "`n"
                
                $ColumnText -join ";" | add-content $eaffile
            }
        }
    }
    
    
    ### Run Profiles
    if ($hashRP.ContainsKey($MAid) -and $hashRP.($MAid).count -gt 0)
    {
        foreach ($RP in $hashRP.($MAid).Keys | sort)
        {                

            $ColumnText = @()
            $ColumnText += $MAName
            $ColumnText += $RP
            $ColumnText += $hashRP.($MAid).($RP)
            
            $ColumnText -join ";" | add-content $rpfile
        }
    }

    
}


